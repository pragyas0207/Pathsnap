PathSnap frontend laptop

1. Extract this ZIP. Python 3 must be installed.
2. Run START_UI.cmd and keep that window open.
3. Open http://localhost:5500 .
4. Backend address: http://10.1.24.198:8766 . Click Connect & load trips.
5. Choose any of the ten trips and click Match route.
6. Match the displayed request ID to the log on the backend laptop.

Both laptops must share a network that allows device-to-device access.
If the backend Wi-Fi IP changes, edit the Backend address field.
This package contains no dataset, reference routes or model weights.
Leaflet assets are local; optional OpenStreetMap background tiles need internet.
Pointwise scores are reference-alignment proxies.
