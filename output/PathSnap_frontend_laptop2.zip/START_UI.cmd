@echo off
cd /d "%~dp0"
echo Open http://localhost:5500 in your browser. Keep this window open.
python -m http.server 5500 --bind 127.0.0.1 --directory frontend
pause
